try it https://denisknk.github.io/Football-game-with-DOM-node/
